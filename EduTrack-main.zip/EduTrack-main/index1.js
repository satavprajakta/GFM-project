const mongoose = require("mongoose");
const studentsdata = require("./studentsdata.js");
const students = require("../models/student.js");


const MONGO_URL = "mongodb://127.0.0.1:27017/EDUCARE";

main()
.then(()=>{
    console.log("connected to DB");
})
.catch((err)=>{
    console.error(err);
});

async function main(){
    await mongoose.connect(MONGO_URL);
}

const initDB = async ()=>{
    try {
        await students.deleteMany({});
        await students.insertMany(studentsdata);
        console.log("data was initialized");
    } catch (err) {
        console.error(err);
    }
};

initDB();
